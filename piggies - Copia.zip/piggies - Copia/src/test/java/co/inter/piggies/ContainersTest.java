package co.inter.piggies;

import io.micronaut.test.support.TestPropertyProvider;
import org.testcontainers.kafka.KafkaContainer;
import org.testcontainers.postgresql.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

import java.util.Map;

public abstract class ContainersTest implements TestPropertyProvider {

    static final PostgreSQLContainer POSTGRES =
            new PostgreSQLContainer(DockerImageName.parse("postgres:16-alpine"));

    static final KafkaContainer KAFKA =
            new KafkaContainer(DockerImageName.parse("apache/kafka-native:4.3.1"));

    static {
        POSTGRES.start();
        KAFKA.start();
    }

    @Override
    public Map<String, String> getProperties() {
        return Map.of(
                "datasources.default.url", POSTGRES.getJdbcUrl(),
                "datasources.default.username", POSTGRES.getUsername(),
                "datasources.default.password", POSTGRES.getPassword(),
                "datasources.default.driverClassName", "org.postgresql.Driver",
                "kafka.bootstrap.servers", KAFKA.getBootstrapServers()
        );
    }
}