package co.inter.piggies;

import io.micronaut.context.ApplicationContext;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static org.assertj.core.api.Assertions.assertThat;

@MicronautTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class PiggiesApplicationTest extends ContainersTest {

    @Inject
    ApplicationContext applicationContext;

    @Test
    void contextLoads() {
        assertThat(applicationContext.isRunning()).isTrue();
    }
}