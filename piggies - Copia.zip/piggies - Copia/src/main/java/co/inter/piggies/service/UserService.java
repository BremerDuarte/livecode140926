package co.inter.piggies.service;

import co.inter.piggies.domain.Users;
import co.inter.piggies.dto.request.CreateUserRequest;
import co.inter.piggies.dto.response.UserResponse;
import co.inter.piggies.event.UserCreatedEvent;
import co.inter.piggies.producer.UserProducer;
import co.inter.piggies.repository.UserRepository;
import jakarta.inject.Singleton;
import jakarta.transaction.Transactional;

import java.util.UUID;

@Singleton
public class UserService {

    private final UserRepository repository;
    private final UserProducer producer;

    public UserService(UserRepository repository, UserProducer producer) {
        this.repository = repository;
        this.producer = producer;
    }

    @Transactional
    public UserResponse create(CreateUserRequest request) {
        // 1. Evita criar o mesmo usuário se o e-mail já existir
        return repository.findByEmail(request.email())
                .map(existingUser -> new UserResponse(existingUser.getName()))
                .orElseGet(() -> {
                    Users user = new Users();
                    user.setName(request.name());
                    user.setEmail(request.email());

                    // Salva no banco de dados
                    repository.save(user);

                    // 2. Gera o UUID único para garantir a idempotência no Consumer
                    UUID eventId = UUID.randomUUID();

                    // 3. Publica o evento no Kafka
                    producer.publish(new UserCreatedEvent(
                            eventId,
                            user.getId(),
                            user.getName(),
                            user.getEmail()
                    ));

                    return new UserResponse(user.getName());
                });
    }
}