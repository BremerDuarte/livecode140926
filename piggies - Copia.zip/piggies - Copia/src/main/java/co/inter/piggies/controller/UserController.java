package co.inter.piggies.controller;

import co.inter.piggies.dto.request.CreateUserRequest;
import co.inter.piggies.dto.response.UserResponse;
import co.inter.piggies.service.UserService;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import jakarta.validation.Valid;

@Controller("/users")
public class UserController {
    private final UserService service;

    public UserController(UserService service) {
        this.service = service;
    }

    @Post
    public HttpResponse<UserResponse> create(@Body @Valid CreateUserRequest request) {
        return HttpResponse.created(service.create(request));
    }
}

