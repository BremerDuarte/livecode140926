package co.inter.piggies.dto.request;

import io.micronaut.serde.annotation.Serdeable;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@Serdeable
public record CreateUserRequest(

        @NotBlank
        String name,

        @Email
        String email

) {
}

