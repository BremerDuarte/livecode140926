package co.inter.piggies.event;

import io.micronaut.serde.annotation.Serdeable;

import java.util.UUID;
@Serdeable
public record UserCreatedEvent(
        UUID eventId,
        Long id,
        String name,
        String email
) {
}