package co.inter.piggies.dto.response;

import io.micronaut.serde.annotation.Serdeable;

@Serdeable
public record UserResponse(
        String name
) {
}

