package co.inter.piggies.producer;

import co.inter.piggies.event.UserCreatedEvent;
import io.micronaut.configuration.kafka.annotation.KafkaClient;
import io.micronaut.configuration.kafka.annotation.Topic;

@KafkaClient
public interface UserProducer {

    @Topic("user-created")
    void publish(UserCreatedEvent event);
}
