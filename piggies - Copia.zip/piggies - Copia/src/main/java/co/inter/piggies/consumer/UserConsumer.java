//package co.inter.piggies.consumer;
//
//import co.inter.piggies.domain.ProcessedEvent;
//import co.inter.piggies.event.UserCreatedEvent;
//import co.inter.piggies.repository.ProcessedEventRepository;
//import io.micronaut.configuration.kafka.annotation.KafkaListener;
//import io.micronaut.configuration.kafka.annotation.Topic;
//import io.micronaut.retry.annotation.Retryable;
//import jakarta.transaction.Transactional;
//
//import java.time.Instant;
//
//@KafkaListener(groupId = "user-consumer-group")
//public class UserConsumer {
//
//    private final ProcessedEventRepository processedEventRepository;
//
//    public UserConsumer(ProcessedEventRepository processedEventRepository) {
//        this.processedEventRepository = processedEventRepository;
//    }
//
//    @Topic("user-created")
//    @Transactional
//    void receive(UserCreatedEvent event) {
//
//        if (processedEventRepository.existsById(event.eventId())) {
//            System.out.println("Evento " + event.eventId() + " já processado, ignorando");
//            return;
//        }
//
//        System.out.println("Usuário criado: " + event.name());
////        processedEventRepository.save(new ProcessedEvent(event.eventId(), Instant.now()));
//        processedEventRepository.persist(new ProcessedEvent(event.eventId(), Instant.now()));
//    }
//}

package co.inter.piggies.consumer;

import co.inter.piggies.domain.ProcessedEvent;
import co.inter.piggies.event.UserCreatedEvent;
import co.inter.piggies.repository.ProcessedEventRepository;
import io.micronaut.configuration.kafka.annotation.KafkaListener;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.retry.annotation.Retryable;
import io.micronaut.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;

@KafkaListener(groupId = "user-consumer-group")
public class UserConsumer {

    private static final Logger LOG = LoggerFactory.getLogger(UserConsumer.class);
    private final ProcessedEventRepository processedEventRepository;

    public UserConsumer(ProcessedEventRepository processedEventRepository) {
        this.processedEventRepository = processedEventRepository;
    }

    @Topic("user-created")
    @Transactional
    @Retryable(attempts = "3", delay = "500ms") // Protege contra quedas temporárias de banco/infra
    void receive(UserCreatedEvent event) {

        // 1. Idempotência: Mensagem duplicada? Retorna normalmente (sem Retry)
        if (processedEventRepository.existsById(event.eventId())) {
            LOG.warn("Evento {} já processado. Ignorando duplicação.", event.eventId());
            return;
        }

        LOG.info("Processando evento: {}", event.eventId());

        // 2. Se o banco falhar ao gravar aqui, lança exceção e o @Retryable tenta de novo!
        processedEventRepository.persist(new ProcessedEvent(event.eventId(), Instant.now()));

        LOG.info("Evento {} processado com sucesso.", event.eventId());
    }
}