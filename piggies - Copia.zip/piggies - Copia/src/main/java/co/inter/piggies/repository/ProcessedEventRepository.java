package co.inter.piggies.repository;

import co.inter.piggies.domain.ProcessedEvent;
import io.micronaut.data.annotation.Repository;
import io.micronaut.data.jpa.repository.JpaRepository;
import java.util.UUID;

@Repository
public interface ProcessedEventRepository extends JpaRepository<ProcessedEvent, UUID> {
    void persist(ProcessedEvent entity);
}